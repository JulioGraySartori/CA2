document.addEventListener('DOMContentLoaded', () => {
  const board = document.getElementById('game-container');
  const message = document.getElementById('message');

  const hexRadius = 40; // Radius of each hexagon
  const hexHeight = Math.sqrt(3) * hexRadius; // Height of a hexagon
  const rows = 7; // Number of rows in the grid (adjust as needed)

  // Create a hexagonal grid
  function createHexagonalGrid() {
    board.innerHTML = ''; // Clear existing hexagons
    const centerX = board.offsetWidth / 2;
    const centerY = board.offsetHeight / 2;

    for (let row = -rows; row <= rows; row++) {
      for (let col = -rows; col <= rows; col++) {
        // Calculate hexagon position
        const xOffset = 1.5 * hexRadius; // Horizontal spacing
        const yOffset = hexHeight; // Vertical spacing
        const x = centerX + col * xOffset + (row % 2 === 0 ? 0 : xOffset / 2);
        const y = centerY + row * (yOffset * 0.75);

        // Skip hexagons outside the circular layout
        const distance = Math.sqrt(Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2));
        if (distance > 320) continue; // 320 = radius of the circular grid

        // Create the hexagon
        const hexagon = document.createElement('div');
        hexagon.classList.add('hexagon');
        hexagon.style.left = `${x}px`;
        hexagon.style.top = `${y}px`;

        // Add hover and click effects
        hexagon.addEventListener('mouseover', () => hexagon.classList.add('hover'));
        hexagon.addEventListener('mouseout', () => hexagon.classList.remove('hover'));
        hexagon.addEventListener('click', () => hexagon.classList.toggle('selected'));

        board.appendChild(hexagon);
      }
    }
  }

  // Matrix effect
  function createMatrixEffect() {
    const overlay = document.getElementById('matrix-overlay');
    const columns = Math.floor(window.innerWidth / 20); // One column per 20px

    overlay.innerHTML = ''; // Clear existing columns

    for (let i = 0; i < columns; i++) {
      const column = document.createElement('div');
      column.classList.add('matrix-column');
      column.style.left = `${i * 20}px`;
      overlay.appendChild(column);

      const columnText = Array.from({ length: 20 })
        .map(() => String.fromCharCode(0x30a0 + Math.random() * 96))
        .join('<br>'); // Random characters
      column.innerHTML = columnText;

      column.style.animationDuration = `${2 + Math.random() * 3}s`;
      column.style.animationDelay = `${Math.random() * 2}s`;
    }
  }

  // Restart game
  function restartGame() {
    createHexagonalGrid();
    message.textContent = "Player X's Turn";
  }

  // Initialize the game
  createMatrixEffect();
  createHexagonalGrid();

  // Attach restart functionality
  document.querySelector('.restart-btn').addEventListener('click', restartGame);
});
